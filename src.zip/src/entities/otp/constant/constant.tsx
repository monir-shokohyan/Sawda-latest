export const defaultValues = {
  otp: '',
}
