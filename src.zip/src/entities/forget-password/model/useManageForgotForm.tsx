import { useForm } from 'react-hook-form'
import { yupResolver } from '@hookform/resolvers/yup'
import { schema } from '../schema'
import { Responsive } from '@shared/hooks/responsive'
import { ForgetType, TabType } from '../types'
import { defaultValues } from '../constant'
import { useState } from 'react'
import { useSwipeable } from 'react-swipeable'
import { useNavigate } from 'react-router-dom'
import { Paths } from '@shared/api/paths/paths'
import { useTranslation } from 'react-i18next'

const useManageForgotForm = () => {
  const { isMobile } = Responsive()
  const { t } = useTranslation()
  const { control, handleSubmit } = useForm<ForgetType>({
    resolver: yupResolver(schema as any),
    defaultValues,
  })
  const navigate = useNavigate()
  const [filter, setFilter] = useState<TabType>('phone')
  const Toggle = () => {
    setFilter((prev) => (prev === 'email' ? 'phone' : 'email'))
  }
  const handler = useSwipeable({
    onSwipedLeft: () => Toggle(),
    onSwipedRight: () => Toggle(),
    delta: 50,
  })

  const onSubmit = (data: any) => {
    console.log(data)

    navigate({
      pathname: Paths.Otp,
      search: `?${filter}=${encodeURIComponent(data[filter])}`,
    })
  }

  return {
    handleSubmit,
    onSubmit,
    control,
    isMobile,
    handler,
    filter,
    setFilter,
    t,
  }
}

export { useManageForgotForm }
