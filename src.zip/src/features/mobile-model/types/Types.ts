export interface ProductsDetailsProps {}
