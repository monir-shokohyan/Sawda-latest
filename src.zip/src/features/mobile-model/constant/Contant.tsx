const MenuItems = []

export { MenuItems }
