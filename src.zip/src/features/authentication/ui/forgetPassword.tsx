import { ForgetForm } from '@entities/forget-password'
import { Center } from '@mantine/core'
import { Title, Text, Anchor, Stack } from '@mantine/core'
import { Responsive } from '@shared/hooks/responsive'
import { ContainerWithBreadCrumb } from '@shared/ui/container-with-bread-crumb'
import { useTranslation } from 'react-i18next'

export const ForgotPasswordFeature = () => {
  const { isMobile } = Responsive()
  const { t } = useTranslation()

  return (
    <ContainerWithBreadCrumb title="forgot-password">
      <Center>
        <Stack
          gap="sm"
          w={isMobile ? '100%' : '50%'}
          py="5vh"
        >
          <Title
            order={2}
            ta="center"
            c="var(--mantine-primary-color-filled)"
          >
            {t('auth.forgotPassword')}
          </Title>

          <Text
            ta="center"
            c="dimmed"
            size="sm"
          >
            {t('auth.enterEmailToReset')}
          </Text>

          <ForgetForm />

          <Text
            ta="center"
            size="sm"
            c="dimmed"
          >
            {t('auth.rememberedPassword')}
            <Anchor
              href="/login"
              fw={600}
            >
              {t('auth.backToLogin')}
            </Anchor>
          </Text>
        </Stack>
      </Center>
    </ContainerWithBreadCrumb>
  )
}
