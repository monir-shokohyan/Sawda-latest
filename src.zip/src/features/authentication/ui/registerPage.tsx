import { Center } from '@mantine/core'
import { Title, Text, Anchor, Stack } from '@mantine/core'
import { ContainerWithBreadCrumb } from '@shared/ui/container-with-bread-crumb'
import { Responsive } from '@shared/hooks/responsive'
import { RegisterForm } from '@entities/register-form'
import { useTranslation } from 'react-i18next'

export const RegisterFeature = () => {
  const { isMobile } = Responsive()
  const { t } = useTranslation()

  return (
    <ContainerWithBreadCrumb title="register">
      <Center>
        <Stack
          gap="sm"
          w={isMobile ? '100%' : '50%'}
          py="5vh"
        >
          <Stack gap="lg">
            <Title
              order={2}
              ta="center"
              c="var(--mantine-primary-color-filled)"
            >
              {t('auth.createAccount')}
            </Title>

            <Text
              ta="center"
              c="dimmed"
              size="sm"
            >
              {t('auth.signUpToGetStarted')}
            </Text>

            <RegisterForm />

            <Text
              ta="center"
              size="sm"
              c="dimmed"
            >
              {t('auth.alreadyHaveAnAccount')}
              <Anchor
                href="/login"
                fw={600}
              >
                {t('auth.signIn')}
              </Anchor>
            </Text>
          </Stack>
        </Stack>
      </Center>
    </ContainerWithBreadCrumb>
  )
}
